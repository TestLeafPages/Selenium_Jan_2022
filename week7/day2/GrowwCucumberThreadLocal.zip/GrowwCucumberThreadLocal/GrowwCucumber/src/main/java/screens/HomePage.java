package screens;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;
import io.cucumber.java.en.Then;

public class HomePage extends BasePage{
	
//	public HomePage(ChromeDriver driver) {
//		this.driver = driver;
//	}
//	
	/**
	 * This method is to click on CRM/SFA link in Home Page
	 * @return 
	 */
	public MyHomePage clickCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	
	@Then("Homepage should be displayed")
	public HomePage verifyHomePage() {
		System.out.println("Login success");
		return this;
	}

}
