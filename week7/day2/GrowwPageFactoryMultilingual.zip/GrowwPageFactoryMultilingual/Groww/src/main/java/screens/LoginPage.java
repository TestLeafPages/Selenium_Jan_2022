package screens;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import hooks.BasePage;

public class LoginPage extends BasePage{
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/*
	 * @FindBy(how = How.ID, using = "username") WebElement eleUserName;
	 */
	// @FindBys
	@CacheLookup
	@FindAll(
			{
				@FindBy(how = How.CLASS_NAME, using = "inputLogin12"),
				@FindBy(how = How.XPATH, using = "//input[@id='username']")
			}
			) 
	List<WebElement> eleUserName;
	
	/**
	 * Type the user name in the login screen
	 * @param userId -- The different username to login
	 * @return 
	 */
	public LoginPage typeUserName(String userId) {
//		WebElement eleUserName = driver.findElement(By.id("username"));
		try {
		eleUserName.get(0).sendKeys(userId);
		} catch(NoSuchElementException e) {
			System.out.println(e);
		} catch(StaleElementReferenceException e) {
			System.out.println(e);
		}
		return this;
	}
	
	@FindBy(how = How.ID, using = "password") 
	WebElement elePassword;
	/**
	 * Type the password in the login screen
	 * @param password -- The different password to login
	 * @return 
	 */
	public LoginPage typePassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
		return this; 
	}
	
	/**
	 * Click the login button
	 * @return 
	 */
	public HomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage(driver);
	}

}







