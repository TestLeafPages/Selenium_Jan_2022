package tests;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import hooks.BasePage;
import screens.HomePage;
import screens.LoginPage;

public class S12_1021_Login extends BasePage{
	
	@BeforeClass
	public void setData() {
		fileName = "Login";
	}

	@Test(dataProvider = "fetchData")
	public void loginTest(String uName, String pwd, String cName, String fName, String lName) throws InterruptedException {
		
		new LoginPage(driver)
		.typeUserName(uName)
		.typePassword(pwd)
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsTab();
		
		driver.findElement(By.linkText(prop1.getProperty("linkcreatelead"))).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		driver.findElement(By.name("submitButton")).click();
	}
	
}
