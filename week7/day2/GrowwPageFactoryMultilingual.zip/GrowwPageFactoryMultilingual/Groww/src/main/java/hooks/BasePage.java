package hooks;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class BasePage {

	public ChromeDriver driver;
	public String fileName;
	public static Properties prop1;

	@BeforeMethod
	public void launch() throws IOException {

		// driver setup
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/application.properties"));
		prop.load(fis);
		
		driver.get(prop.getProperty("url"));
		String lang = prop.getProperty("language");
		
		prop1 = new Properties();
		FileInputStream fis1 = new FileInputStream(new File("./src/main/resources/"+lang+".properties"));
		prop1.load(fis1);
		
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void tearDown() {
		driver.close();
	}

	@DataProvider(name = "fetchData", indices = 0, parallel = true)
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(fileName);

	}

}
