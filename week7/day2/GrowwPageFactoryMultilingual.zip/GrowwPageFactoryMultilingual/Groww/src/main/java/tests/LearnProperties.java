package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.NoSuchElementException;

public class LearnProperties {

	public static void main(String[] args) throws IOException {
		Properties prop = new Properties();
		
		// Setup file path
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/application.properties"));
		// Load the file to properties
		prop.load(fis);
		
		String url = prop.getProperty("url");
		System.out.println(url);
		System.out.println(prop.getProperty("username"));
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			System.out.println();
		}
		
	}
}
