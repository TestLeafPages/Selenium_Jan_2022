package tests;

public class LearnExceptionHandling {

	public static void main(String[] args) {
		int a = 10;
		int b = 2;

		int[] arr = { 1, 2, 3 };

		try {
			System.out.println(a / b);
			System.out.println("In try");
			try {
				System.out.println(arr[2]);
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
			}
		} catch (ArithmeticException e) {
			System.out.println(e);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		} finally {
			System.out.println("Finally");
		}
		throw new RuntimeException("Runtime");
//		System.out.println("Last line of code");
	}
}
